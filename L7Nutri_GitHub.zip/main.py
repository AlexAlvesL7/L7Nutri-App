from flask import Flask, request, jsonify, render_template, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
import os
from datetime import date, datetime, timedelta
import google.generativeai as genai

# --- Configuração do Google Gemini AI ---
gemini_api_key = os.getenv('GEMINI_API_KEY')
if gemini_api_key and gemini_api_key != 'SUA_CHAVE_AQUI':
    genai.configure(api_key=gemini_api_key)
    modelo_ia = genai.GenerativeModel('gemini-1.5-flash')
    print("Google Gemini AI configurado com sucesso!")
else:
    modelo_ia = None
    print("GEMINI_API_KEY nao configurada. Recursos de IA estarao desabilitados.")

# --- Configuração do Aplicativo Flask ---
app = Flask(__name__)
bcrypt = Bcrypt(app)

# Configuração do JWT
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'super-secret-key')
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(days=365)  # 1 ano
jwt = JWTManager(app)

# Configura a chave secreta para a aplicação
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'l7nutri-secret-key-2025')

# === CONFIGURAÇÃO DO BANCO DE DADOS ===
DATABASE_URL = os.getenv('DATABASE_URL')
if DATABASE_URL:
    # Render PostgreSQL (produção)
    if DATABASE_URL.startswith('postgres://'):
        DATABASE_URL = DATABASE_URL.replace('postgres://', 'postgresql://', 1)
    app.config['SQLALCHEMY_DATABASE_URI'] = DATABASE_URL
    print("MODO PRODUCAO: Usando PostgreSQL Render")
else:
    # Desenvolvimento local (SQLite)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///nutricao.db'
    print("MODO DESENVOLVIMENTO: Usando SQLite local")

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inicializar SQLAlchemy
db = SQLAlchemy(app)

# === MODELOS DO BANCO DE DADOS ===
class Usuario(db.Model):
    __tablename__ = 'usuarios'
    
    id = db.Column(db.Integer, primary_key=True)
    nome_usuario = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    senha_hash = db.Column(db.String(255), nullable=False)
    data_criacao = db.Column(db.DateTime, default=db.func.current_timestamp())
    
    def __repr__(self):
        return f'<Usuario {self.nome_usuario}>'

class Alimento(db.Model):
    __tablename__ = 'alimentos'
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    calorias = db.Column(db.Numeric(10, 2), nullable=False)
    proteinas = db.Column(db.Numeric(10, 2), nullable=False)
    carboidratos = db.Column(db.Numeric(10, 2), nullable=False)
    gorduras = db.Column(db.Numeric(10, 2), nullable=False)
    
    def __repr__(self):
        return f'<Alimento {self.nome}>'

class Diario(db.Model):
    __tablename__ = 'diarios'
    
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'), nullable=False)
    data_entrada = db.Column(db.Date, nullable=False)
    alimento_id = db.Column(db.Integer, db.ForeignKey('alimentos.id'), nullable=False)
    quantidade = db.Column(db.Numeric(10, 2), nullable=False)
    
    # Relacionamentos
    usuario = db.relationship('Usuario', backref='diarios')
    alimento = db.relationship('Alimento', backref='diarios')
    
    def __repr__(self):
        return f'<Diario {self.usuario_id} - {self.alimento_id}>'

# === ROTAS DA APLICAÇÃO ===

@app.route('/')
def index():
    """Página inicial"""
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Página de login"""
    if request.method == 'POST':
        data = request.get_json()
        nome_usuario = data.get('nome_usuario')
        senha = data.get('senha')
        
        if not nome_usuario or not senha:
            return jsonify({'erro': 'Nome de usuário e senha são obrigatórios'}), 400
        
        usuario = Usuario.query.filter_by(nome_usuario=nome_usuario).first()
        
        if usuario and bcrypt.check_password_hash(usuario.senha_hash, senha):
            access_token = create_access_token(identity=usuario.id)
            session['user_id'] = usuario.id
            session['nome_usuario'] = usuario.nome_usuario
            return jsonify({
                'mensagem': 'Login realizado com sucesso',
                'token': access_token,
                'usuario': {
                    'id': usuario.id,
                    'nome_usuario': usuario.nome_usuario,
                    'email': usuario.email
                }
            })
        else:
            return jsonify({'erro': 'Credenciais inválidas'}), 401
    
    return render_template('login.html')

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    """Página de cadastro"""
    if request.method == 'POST':
        data = request.get_json()
        nome_usuario = data.get('nome_usuario')
        email = data.get('email')
        senha = data.get('senha')
        
        if not nome_usuario or not email or not senha:
            return jsonify({'erro': 'Todos os campos são obrigatórios'}), 400
        
        # Verificar se usuário já existe
        if Usuario.query.filter_by(nome_usuario=nome_usuario).first():
            return jsonify({'erro': 'Nome de usuário já existe'}), 400
        
        if Usuario.query.filter_by(email=email).first():
            return jsonify({'erro': 'Email já está em uso'}), 400
        
        # Criar novo usuário
        senha_hash = bcrypt.generate_password_hash(senha).decode('utf-8')
        novo_usuario = Usuario(
            nome_usuario=nome_usuario,
            email=email,
            senha_hash=senha_hash
        )
        
        db.session.add(novo_usuario)
        db.session.commit()
        
        return jsonify({
            'mensagem': 'Usuário criado com sucesso',
            'usuario': {
                'id': novo_usuario.id,
                'nome_usuario': novo_usuario.nome_usuario,
                'email': novo_usuario.email
            }
        })
    
    return render_template('cadastro.html')

@app.route('/logout')
def logout():
    """Logout do usuário"""
    session.clear()
    return redirect(url_for('index'))

@app.route('/diario')
def diario():
    """Página do diário alimentar"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('diario.html')

@app.route('/dashboard-insights')
def dashboard_insights():
    """Dashboard de insights com IA"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard_insights.html')

@app.route('/api/alimentos')
def api_alimentos():
    """API para listar alimentos"""
    alimentos = Alimento.query.all()
    return jsonify([{
        'id': alimento.id,
        'nome': alimento.nome,
        'calorias': float(alimento.calorias),
        'proteinas': float(alimento.proteinas),
        'carboidratos': float(alimento.carboidratos),
        'gorduras': float(alimento.gorduras)
    } for alimento in alimentos])

@app.route('/api/diario', methods=['GET', 'POST'])
@jwt_required()
def api_diario():
    """API para gerenciar diário alimentar"""
    usuario_id = get_jwt_identity()
    
    if request.method == 'POST':
        data = request.get_json()
        
        entrada = Diario(
            usuario_id=usuario_id,
            data_entrada=datetime.strptime(data['data_entrada'], '%Y-%m-%d').date(),
            alimento_id=data['alimento_id'],
            quantidade=data['quantidade']
        )
        
        db.session.add(entrada)
        db.session.commit()
        
        return jsonify({'mensagem': 'Entrada adicionada com sucesso'})
    
    # GET - listar entradas
    data_consulta = request.args.get('data', date.today().strftime('%Y-%m-%d'))
    data_obj = datetime.strptime(data_consulta, '%Y-%m-%d').date()
    
    entradas = db.session.query(Diario, Alimento).join(Alimento).filter(
        Diario.usuario_id == usuario_id,
        Diario.data_entrada == data_obj
    ).all()
    
    return jsonify([{
        'id': diario.id,
        'alimento': alimento.nome,
        'quantidade': float(diario.quantidade),
        'calorias': float(alimento.calorias) * float(diario.quantidade) / 100,
        'proteinas': float(alimento.proteinas) * float(diario.quantidade) / 100,
        'carboidratos': float(alimento.carboidratos) * float(diario.quantidade) / 100,
        'gorduras': float(alimento.gorduras) * float(diario.quantidade) / 100
    } for diario, alimento in entradas])

@app.route('/api/insights')
@jwt_required()
def api_insights():
    """API para gerar insights com IA"""
    if not modelo_ia:
        return jsonify({'erro': 'IA não configurada'}), 500
    
    usuario_id = get_jwt_identity()
    
    # Buscar dados dos últimos 7 dias
    data_fim = date.today()
    data_inicio = data_fim - timedelta(days=7)
    
    entradas = db.session.query(Diario, Alimento).join(Alimento).filter(
        Diario.usuario_id == usuario_id,
        Diario.data_entrada >= data_inicio,
        Diario.data_entrada <= data_fim
    ).all()
    
    if not entradas:
        return jsonify({'insights': 'Não há dados suficientes para análise. Adicione mais entradas no seu diário.'})
    
    # Preparar dados para a IA
    dados_nutricao = []
    for diario, alimento in entradas:
        dados_nutricao.append({
            'data': diario.data_entrada.strftime('%Y-%m-%d'),
            'alimento': alimento.nome,
            'quantidade': float(diario.quantidade),
            'calorias': float(alimento.calorias) * float(diario.quantidade) / 100,
            'proteinas': float(alimento.proteinas) * float(diario.quantidade) / 100,
            'carboidratos': float(alimento.carboidratos) * float(diario.quantidade) / 100,
            'gorduras': float(alimento.gorduras) * float(diario.quantidade) / 100
        })
    
    # Gerar prompt para a IA
    prompt = f"""
    Analise os dados nutricionais dos últimos 7 dias e forneça insights personalizados:
    
    Dados: {dados_nutricao}
    
    Forneça:
    1. Análise do padrão alimentar
    2. Pontos fortes da dieta
    3. Áreas para melhoria
    4. Sugestões específicas
    5. Meta para os próximos dias
    
    Responda de forma amigável e motivadora.
    """
    
    try:
        resposta = modelo_ia.generate_content(prompt)
        return jsonify({'insights': resposta.text})
    except Exception as e:
        return jsonify({'erro': f'Erro ao gerar insights: {str(e)}'}), 500

# === INICIALIZAÇÃO DO BANCO E DADOS ===
with app.app_context():
    db.create_all()
    
    # Criar usuário admin se não existir
    if not Usuario.query.filter_by(nome_usuario='admin').first():
        senha_hash = bcrypt.generate_password_hash('admin123').decode('utf-8')
        admin = Usuario(
            nome_usuario='admin',
            email='admin@l7nutri.com',
            senha_hash=senha_hash
        )
        db.session.add(admin)
        db.session.commit()
        print("Usuário admin criado!")
    
    # Adicionar alimentos se não existirem
    if Alimento.query.count() == 0:
        alimentos_base = [
            ("Arroz Branco, cozido", 130, 2.7, 28.2, 0.3),
            ("Feijao Preto, cozido", 132, 8.9, 23.0, 0.5),
            ("Frango, peito sem pele", 165, 31.0, 0.0, 3.6),
            ("Ovo de galinha, cozido", 155, 13.0, 1.1, 11.0),
            ("Banana, madura", 89, 1.1, 22.8, 0.3),
            ("Batata doce, cozida", 86, 1.6, 20.1, 0.1),
            ("Brocolis, cozido", 34, 2.8, 7.0, 0.4),
            ("Cenoura, crua", 41, 0.9, 9.6, 0.2),
            ("Tomate, maduro", 18, 0.9, 3.9, 0.2),
            ("Alface, crespa", 15, 1.4, 3.0, 0.1),
            ("Aveia em Flocos", 389, 16.9, 66.3, 6.9),
            ("Tapioca (Goma hidratada)", 240, 0.0, 60.0, 0.0),
            ("Pao de Queijo", 335, 5.5, 37.5, 18.0),
            ("Milho Verde, cozido", 86, 3.2, 19.0, 1.2),
            ("Carne de Porco (Bisteca), grelhada", 283, 25.8, 0.0, 19.3),
            ("Sardinha em Lata (em oleo)", 208, 24.6, 0.0, 11.5),
            ("Linguica Toscana, grelhada", 322, 16.0, 0.7, 28.0),
            ("Tofu", 76, 8.1, 1.9, 4.8),
            ("Uva Thompson", 69, 0.7, 18.1, 0.2),
            ("Manga Palmer", 60, 0.8, 15.0, 0.4),
            ("Couve Manteiga, refogada", 90, 2.7, 7.6, 6.1),
            ("Quiabo, cozido", 33, 1.9, 7.0, 0.2),
            ("Palmito Pupunha, em conserva", 28, 2.5, 4.2, 0.3),
            ("Batata Inglesa, cozida", 87, 1.9, 19.6, 0.1),
            ("Carne Bovina, alcatra", 163, 29.2, 0.0, 4.8),
            ("Leite integral", 61, 3.2, 4.6, 3.2),
        ]
        
        for nome, cal, prot, carb, gord in alimentos_base:
            alimento = Alimento(
                nome=nome,
                calorias=cal,
                proteinas=prot,
                carboidratos=carb,
                gorduras=gord
            )
            db.session.add(alimento)
        
        db.session.commit()
        print(f"Base de Ouro adicionada: {len(alimentos_base)} alimentos!")

if __name__ == '__main__':
    # Configuração do servidor
    port = int(os.getenv('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
